import { pool } from "./db";

export async function insertUser(data: any) {
  const sql = `INSERT INTO users (firstname, lastname, email, password) VALUES (?, ?, ?, ?)`;
  const params = [data.firstname, data.lastname, data.email, data.password];
  const [rows]: any = await pool.query(sql, params);
  return rows;
}

export async function selectUsers() {
  const [rows]: any = await pool.query(`SELECT uid, firstname, lastname, email FROM users`);
  return rows;
}

export async function selectUserById(id: string) {
  const [rows]: any = await pool.query(`SELECT * FROM users WHERE uid = ?`, [id]);
  return rows[0];
}

export async function updateUserById(id: string, data: any) {
  const sql = `UPDATE users SET firstname=?, lastname=?, email=? WHERE uid=?`;
  const params = [data.firstname, data.lastname, data.email, id];
  const [rows]: any = await pool.query(sql, params);
  return rows;
}

export async function deleteUserById(id: string) {
  const [rows]: any = await pool.query(`DELETE FROM users WHERE uid = ?`, [id]);
  return rows;
}
