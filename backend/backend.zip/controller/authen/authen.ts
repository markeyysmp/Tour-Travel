import express from "express";
import { register, login } from "../../models/auth";
export const auth = express.Router();

// REGISTER
auth.post("/register", async (req: any, res: any) => {
    const { firstname, lastname, email, password, passwordConfirm, regType } = req.body;

    if (regType === "email" && (!firstname || !lastname || !email || !password || !passwordConfirm)) {
        return res.status(400).json({ message: "กรุณากรอกข้อมูลให้ครบถ้วน" });
    }

    const validPattern = /^[A-Za-z\u0E00-\u0E7F]+$/;

    if (!validPattern.test(firstname) || !validPattern.test(lastname)) {
        return res.status(400).json({
            message: "ชื่อผู้ใช้ต้องเป็นภาษาไทยหรืออังกฤษเท่านั้น",
        });
    }

    if (password !== passwordConfirm)
        return res.status(400).json({ message: "รหัสผ่านไม่ตรงกัน" });

    try {
        const result = await register(firstname, lastname, email, password, regType);

        if (!result.success) {
            return res.status(409).json({ message: result.message });
        }

        res.status(201).json(result);
    } catch (error: any) {
        console.error("เกิดข้อผิดพลาดในการสมัคร:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
});


// LOGIN
auth.post("/login", async (req: any, res: any) => {
    const { email, password } = req.body;

    if (!email || !password)
        return res.status(400).json({ message: "กรุณากรอกข้อมูลให้ครบถ้วน" });

    try {
        const result = await login(email, password);

        res.status(200).json({
            success: true,
            token: result.token
        });

    } catch (error: any) {
        console.error("Login Error:", error);
        res.status(401).json({ success: false, message: error.message });
    }
});
