import express from "express";
import passport from "passport";
import jwt from "jsonwebtoken";
import { pool } from "../models/db";

export const googleAuth = express.Router();

// ไปหน้า Login ของ Google
googleAuth.get("/google",
	passport.authenticate("google", { scope: ["profile", "email"] })
);

// Google กลับมาหน้านี้
googleAuth.get("/google/callback",
	passport.authenticate("google", { session: false }),
	async (req: any, res) => {

		const profile = req.user;
		const email = profile.emails[0].value;
		const firstname = profile.name.givenName;
		const lastname = profile.name.familyName;

		// เช็คว่ามี user อยู่แล้วไหม
		const [rows]: any = await pool.query(
			"SELECT * FROM users WHERE email = ?",
			[email]
		);

		let uid;

		if (rows.length === 0) {
			// สมัครอัตโนมัติ
			const [insert]: any = await pool.query(
				`INSERT INTO users (firstname, lastname, email, regType)
				 VALUES (?, ?, ?, 'google')`,
				[firstname, lastname, email]
			);
			uid = insert.insertId;
		} else {
			uid = rows[0].uid;
		}

		// สร้าง token
		const token = jwt.sign(
			{ uid, email, firstname, lastname },
			"SECRETKEY",
			{ expiresIn: "1d" }
		);

		// ส่งกลับไป Angular (ผ่าน query string)
		res.redirect(
			`http://localhost:4200/auth/callback?token=${token}`
		);
	}
);
