import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";

passport.use(
	new GoogleStrategy(
		{
			clientID: "742192009707-pke88mk0g7ed94aflnjgj50pf88j2cg7.apps.googleusercontent.com",
			clientSecret: "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",
			callbackURL: "http://localhost:3000/api/auth/google/callback"
		},
		(accessToken, refreshToken, profile, done) => {
			return done(null, profile);
		}
	)
);

export default passport;
